package at.fhj.itm;

public class StackMain {

	public static void main(String[] args) {
		System.out.println("Neuen Stack mit Gr��e 7 anlegen");
		StringStack stack = new StringStack(7);
		System.out.println("Ist der Stack leer?: " + stack.isEmpty());
		System.out.println("Pop: " + stack.pop());
		
		System.out.println("7 mal Push mit test1 bis test7");
		stack.push("test1");
		stack.push("test2");
		stack.push("test3");
		stack.push("test4");
		stack.push("test5");
		stack.push("test6");
		stack.push("test7");
		
		System.out.println();
		
		System.out.println("Pusch test8");
		stack.push("test8");
		System.out.println("Pop: " + stack.pop());
		System.out.println("Ist der Stack leer?: " + stack.isEmpty());
	}

}
