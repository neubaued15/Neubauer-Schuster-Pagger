package at.fhj.itm;

public class QueueMain {

	public static void main(String[] args) {
		System.out.println("Neue Queue mit Gr��e 5 anlegen");
		StringQueue queue = new StringQueue(5);
		
		System.out.println("Poll: " + queue.poll());
		//System.out.println("Remove: " + queue.remove());
		System.out.println("Peek: " + queue.peek());
		//System.out.println("Element: " + queue.element());
		
		System.out.println("Offer Test1: " + queue.offer("Test1"));
		System.out.println("Offer Test2: " + queue.offer("Test2"));
		System.out.println("Offer Test3: " + queue.offer("Test3"));
		System.out.println("Offer Test4: " + queue.offer("Test4"));
		System.out.println("Offer Test5: " + queue.offer("Test5"));
		System.out.println("Offer Test6: " + queue.offer("Test6"));
		
		System.out.println("Poll: " + queue.poll());
		System.out.println("Poll: " + queue.poll());
		System.out.println("Remove: " + queue.remove());
		System.out.println("Remove: " + queue.remove());
		System.out.println("Peek: " + queue.peek());
		System.out.println("Element: " + queue.element());
	}

}
