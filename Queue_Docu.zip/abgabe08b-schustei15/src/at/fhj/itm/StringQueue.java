package at.fhj.itm;

import java.util.NoSuchElementException;
/**
 * 
 * @author Ingo
 * Erstellt eine String Queue
 * Bietet M�glichkeiten der Queue Elemente hinzutuf�gen und zu entfernen
 *
 */
public class StringQueue implements Queue {

	String[] queue;			
	int queuepointer = 0;	//Zeigt auf das hinterste Element
	int i;					//Gr��e der Queue
	String element;			//Returnwert f�r das String Element
/**
 * 
 * @param i gibt die Queue Gr��e an
 * Verringert i um eins weil Arraypointer mit null startet
 */
	public StringQueue(int i) {
		queue = new String[i];
		this.i = i;
		this.i--;
	}

	@Override
	/**
	 * F�gt ein Element der Queue hinzu:
	 * wenn dies gelingt return true und Queuepointer wird erh�ht
	 * wenn nicht => Pointer gr��er i, dann return false
	 */
	public boolean offer(String obj) {
		if (queuepointer > i) {
			return false;
		} else {
			queue[queuepointer] = obj;
			queuepointer++;
			return true;
		}
	}

	@Override
	/**
	 * Returnt das erste Element in der Queue und l�scht es auch
	 * Wenn die Queue leer ist return Null
	 */
	public String poll() {
		if (queue[0] == null) {
			return null;
		}
		else{
			element = queue[0];
			
			for (int u = 0; u < i; u++) {    
			    queue[u] = queue[u+1];
			}
			queuepointer--;	
			return element;
		}
	}

	@Override
	/**
	 * Verh�lt sich gleich wie poll()
	 * Mit der Ausnahme das bei leerer Queue eine NoSuchElementException() geworfen wird
	 */
	public String remove() {
		if (queue[0] == null) {
			throw new NoSuchElementException();
		}
		else{
		element = queue[0];
			
			for (int u = 0; u < i; u++) {    
			    queue[u] = queue[u+1];
			}
			queuepointer--;	
			return element;
		}
	}

	@Override
	/**
	 * Returnt das erste Element in der Queue und l�scht es nicht
	 * Wenn die Queue leer ist return Null
	 */
	public String peek() {
		if (queue[0] == null) {
			return null;
		}
		else{
			element = queue[0];
			
			return element;
		}
	}

	@Override
	/**
	 * Verh�lt sich gleich wie peek()
	 * Mit der Ausnahme das bei leerer Queue eine NoSuchElementException() geworfen wird
	 */
	public String element() {
		if (queue[0] == null) {
			throw new NoSuchElementException();
		}
		else{
			element = queue[0];
			
			return element;
		}
	}

}
