package at.fhj.itm;

/** Description of String Stack
 *
 *@author Christian Pagger
 *
 * Stack Implementation of <code>Stack</code> Interface.
 * supports String Values and can be initialized with a maximum number
 * of items.
 *  
 * @see Stack
 */
public class StringStack implements Stack
{
	/**Beschreibung der privaten Variablen
	 * in der Variable stack werden Werte gespeichert
	 * der stackpointer zeigt auf die aktive Position im Stack
	 * das element ist ein Teil eines Stacks
	 * i ist die gr��e des Stack
	 */
	private String[] stack;
	private int stackpointer = -1;
	private String element;
	private int i;
	
	/**
	 *StringStack inizialisiert einen neuen Stack
	 */
	public StringStack(int i) {
		stack = new String[i];
		this.i = i;
		this.i--;
	}

	/**
	 * mit der Methode isEmpty wird �berpr�ft ob der Stack leer ist
	 */
	@Override
	public boolean isEmpty() {
		if (stack[0] == null)
		{
			return true;
		}
		return false;
	}

	/**
	 * mit der Methode push wird ein neues Element auf den Stack gelegt
	 */
	@Override
	public void push(String item) {
		if (stackpointer == i){
			System.out.println("Error");
		}
		else{
			stackpointer++;	
			stack[stackpointer] = item;	
		}
	}

	/**
	 * mit der Methoe pop wird das letzte Element vom Stack entfert
	 */
	@Override
	public String pop() {
		if (stackpointer <= 0){
			return "Error";
		}
		element = stack[stackpointer];
		stack[stackpointer] = null;
		stackpointer--;
		return element;
	}

}
